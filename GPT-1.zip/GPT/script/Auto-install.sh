apt update && clear && apt upgrade && clear && apt install python && clear && apt install python-pip && clear && apt install figlet && clear && pkg install termux-api && clear && chmod +rwx install.sh && chmod +x key.py && chmod +x Auto-install.sh && chmod +x setup.sh && chmod +x gpt.py && clear && bash setup.sh && clear && termux-open-url https://platform.openai.com/account/api-keys && nano key.py && clear && ./install.sh
 

