figlet GPT

echo '{UA}'

echo 'Для того щоб Вийти напишіть / скопійуйте команду та втавьте скопійований текст в Termux : exit aбо bye!'

echo 'Ваше API було вже скопійоване та добавлене для роботи з GPT-AI'

echo 'URL : Адресса сайта реєстрації [https://platform.openai.com/account/api-keys]'

echo 'ВАШ АРІ-OPENAI [Зареєстрований за Адрессою] (API-ключ : key.py)'

echo '{RUS}'

echo 'Для того чтобы Выйти напишите/скопируйте команду и вставьте скопированный текст в Termux: exit или bye!'

echo 'Ваш API уже было скопировано и добавлено для работы с GPT-AI'

echo 'URL : Адреса сайта регистрации [https://platform.openai.com/account/api-keys]'

echo 'ВАШ АРI-OPENAI [Зарегистрированный по Адресу] (API-ключ : key.py)'

echo '{USA}/{UK}'

echo 'To Exit type/copy the command and paste the copied text into Termux: exit or bye!'

echo 'Your API has already been copied and pasted to work with GPT-AI'

echo 'URL : Registration Site URLs [https://platform.openai.com/account/api-keys]'

echo 'YOUR API-OPENAI [Registered at Address] (API Key : key.py)'

python gpt.py
